import numpy as np
import pandas as pd
from numpy import mean
from numpy import std
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import RFECV
from sklearn import model_selection
from sklearn.model_selection import train_test_split, KFold, cross_val_score, RepeatedStratifiedKFold
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import classification_report, auc, roc_auc_score, accuracy_score, recall_score, precision_score, f1_score, plot_confusion_matrix, confusion_matrix
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
import lightgbm as lgb
from sklearn.metrics import classification_report,confusion_matrix, roc_curve
import pickle


train = pd.read_csv('C:/Users/HP/Downloads/Data_TrainingWiDS2021.csv')
test = pd.read_csv('C:/Users/HP/Downloads/Data_UnlabeledWiDS2021.csv')
train['train_data']=1
test['train_data']=0
test['diabetes_mellitus']=np.NaN
all_data=pd.concat([train, test])


apache_cols = all_data.columns[all_data.columns.str.contains('apache')]
print(apache_cols)
apache_cols = [c.split('_apache')[0] for c in apache_cols] 
print(apache_cols)

vital_cols = all_data.columns[all_data.columns.str.startswith('d1') & all_data.columns.str.contains('_max')]
print(vital_cols)
vital_cols = [(c.split('d1_')[1]).split('_max')[0] for c in vital_cols]

common_cols = [c for c in apache_cols if c in vital_cols]
print(common_cols)

for c in common_cols:
    var1 = f"d1_{c}_max"
    var2 = f"{c}_apache"
    notna_condition = all_data[var1].notna() & all_data[var2].notna()

    print(f"{c} has {np.round((all_data[notna_condition][var2]==(all_data[notna_condition][var1])).sum()/len(all_data[notna_condition])*100,2)}% duplicates")
for c in common_cols:
    if c not in ['resprate', 'temp']:
        all_data[f"d1_{c}_max"] = np.where((all_data[f"d1_{c}_max"].isna() 
                                            & all_data[f"{c}_apache"].notna()), 
                                           all_data[f"{c}_apache"], 
                                           all_data[f"d1_{c}_max"])

        
        all_data.drop(f"{c}_apache", axis=1, inplace=True)

      
all_data["d1_heartrate_max"] = np.where((all_data["d1_heartrate_max"].isna() 
                                    & all_data["heart_rate_apache"].notna()), 
                                   all_data["heart_rate_apache"], 
                                   all_data["d1_heartrate_max"])

all_data.drop("heart_rate_apache", axis=1, inplace=True)
for col in vital_cols:
    min_col = f"d1_{col}_min"
    max_col = f"d1_{col}_max"
    all_data.loc[all_data[min_col] > all_data[max_col],[min_col, max_col]] = all_data.loc[all_data[min_col] > all_data[max_col], [max_col, min_col]].values
cols_to_drop = []
for i, col_1 in enumerate(all_data.columns):
    for col_2 in all_data.columns[(i+1):]:
        if all_data[col_1].equals(all_data[col_2]):
            print(f"{col_1} and {col_2} are identical.")
            cols_to_drop.append(col_2)
            
all_data.drop(cols_to_drop, axis=1, inplace = True)
all_data["d1_pao2fio2ratio_max"] = np.where((all_data["pao2_apache"].notna() 
                                             & all_data["fio2_apache"].notna()
                                             & all_data["d1_pao2fio2ratio_max"].isna() ), 
                                            all_data["pao2_apache"] / all_data["fio2_apache"], 
                                            all_data["d1_pao2fio2ratio_max"])
drop_columns = all_data.columns[all_data.columns.str.startswith('h1')]
all_data.drop(drop_columns, axis=1, inplace=True)
all_data.drop(columns = ['Unnamed: 0', 'encounter_id', 'hospital_id', 'readmission_status'], inplace=True)

all_data = all_data[all_data['age']>=16].reset_index(drop=True)

all_data['ethnicity'] = all_data['ethnicity'].fillna('Other/Unknown')
all_data['gender'] = all_data['gender'].fillna(all_data['gender'].mode())[0]

all_data["weight"] = np.where((all_data["weight"].isna() 
                                    & all_data["bmi"].notna()), 
                                   all_data["bmi"], 
                                   all_data["weight"])

all_data["height"] = np.where((all_data["height"].isna() 
                                    & all_data["weight"].notna()), 
                                   all_data["weight"], 
                                   all_data["height"])

all_data['height'] = all_data.groupby('gender')['height'].transform(lambda x: x.fillna(x.mean()))
all_data['weight'] = all_data.groupby('gender')['weight'].transform(lambda x: x.fillna(x.mean()))
all_data['bmi'] = all_data.groupby('gender')['bmi'].transform(lambda x: x.fillna(x.mean()))

all_data.loc[all_data['hospital_admit_source'] == 'Acute Care/Floor', 'hospital_admit_source'] = 'Floor'
all_data.loc[all_data['hospital_admit_source'] == 'Step-Down Unit (SDU)', 'hospital_admit_source'] = 'SDU'
all_data.loc[all_data['hospital_admit_source'] == 'ICU to SDU', 'hospital_admit_source'] = 'SDU'
all_data.loc[all_data['hospital_admit_source'] == 'Other ICU', 'hospital_admit_source'] = 'ICU'
all_data.loc[all_data['hospital_admit_source'] == 'PACU', 'hospital_admit_source'] = 'Recovery Room'
all_data.loc[all_data['hospital_admit_source'] == 'SDU', 'hospital_admit_source'] = 'ICU'
all_data.loc[all_data['hospital_admit_source'] == 'Chest Pain Center', 'hospital_admit_source'] = 'Other'
all_data.loc[all_data['hospital_admit_source'] == 'Observation', 'hospital_admit_source'] = 'Other'
all_data['hospital_admit_source'].fillna('Other', inplace = True)

all_data['icu_admit_source'].fillna(all_data['hospital_admit_source'], inplace = True)
all_data.loc[all_data['icu_admit_source'] == 'Operating Room', 'icu_admit_source'] = 'Operating Room / Recovery'
all_data.loc[all_data['icu_admit_source'] == 'Emergency Department', 'icu_admit_source'] = 'Accident & Emergency'
all_data.loc[all_data['icu_admit_source'] == 'Direct Admit', 'icu_admit_source'] = 'Other'
categories = all_data.dtypes[all_data.dtypes == "object"].index
numeric_cols = all_data.dtypes[all_data.dtypes != "object"].index
for i in list(numeric_cols):
  if all_data[i].isna().sum() > 0:
    print(i)

all_dummies = pd.get_dummies(all_data[categories])

all_dummies.head()
all_data = pd.concat([all_data, all_dummies], axis = 1)
all_data = all_data.drop(categories, axis = 1)
all_data.head()
train_data = all_data[all_data['train_data']==1]
test_data = all_data[all_data['train_data']==0]

def subset_by_iqr(df, column, whisker_width=1.5):
    q1 = df[column].quantile(0.25)                 
    q3 = df[column].quantile(0.75)
    iqr = q3 - q1
    filter = (df[column] >= q1 - whisker_width*iqr) & (df[column] <= q3 + whisker_width*iqr)
    return df.loc[filter]                                                     


for feature in all_data.columns:
    cleaned_train_data = subset_by_iqr(train_data, feature, whisker_width=1.5)

cleaned_train_data.shape
all_data=pd.concat([cleaned_train_data, test_data])
def get_correlation(data, threshold):
    corr_col = set()
    corrmat = data.corr()
    for i in range(len(corrmat.columns)):
        for j in range(i):
            if abs(corrmat.iloc[i, j])> threshold:
                colname = corrmat.columns[i]
                corr_col.add(colname)
    print(corrmat)
    return corr_col
corr_features = get_correlation(all_data, 0.80)
len(corr_features)
all_data_uncorr = all_data.drop(labels=corr_features, axis = 1)
data = all_data_uncorr[all_data_uncorr.train_data==1].drop(['train_data'], axis =1)
x = data.drop(['diabetes_mellitus'], axis =1)
y = data['diabetes_mellitus']
x_train,x_val,y_train,y_val = train_test_split(x,y,test_size=0.2, random_state = 40)
x_val.to_csv('Scores1.csv')
y_val.to_csv('Scores2.csv')
x_train.to_csv('Graphics.csv')
test = all_data_uncorr[all_data.train_data==0].drop(['train_data', 'diabetes_mellitus'], axis =1)
test.to_csv('TestingData.csv')
lgb = lgb.LGBMClassifier(silent=False)
lgb.fit(x_train, y_train)
y_pred_lgb=lgb.predict(x_val)

print("Accuracy:",accuracy_score(y_val, y_pred_lgb))
print("Precision:",precision_score(y_val, y_pred_lgb))
print("Recall:",recall_score(y_val, y_pred_lgb))
print("F1 score:",f1_score(y_val, y_pred_lgb))

y_pred_proba = lgb.predict_proba(x_val)[:,1]
print(y_pred_proba)
print("AUC score:",roc_auc_score(y_val, y_pred_proba))
plot_confusion_matrix(lgb, x_val, y_val)
y_pred_proba[0]
Accuracy3 = accuracy_score(y_val, y_pred_lgb)
def plot_feature_importances(df):
    
    df = df.sort_values('importance', ascending = False).reset_index()
    
    df['importance_normalized'] = df['importance'] / df['importance'].sum()


    plt.figure(figsize = (10, 6))
    ax = plt.subplot()
    

    ax.barh(list(reversed(list(df.index[:15]))), 
            df['importance_normalized'].head(15), 
            align = 'center', edgecolor = 'k')
    
    
    ax.set_yticks(list(reversed(list(df.index[:15]))))
    ax.set_yticklabels(df['feature'].head(15))

    plt.xlabel('Normalized Importance'); plt.title('Feature Importances')
    plt.show()
    
    return df

features = list(x_train.columns)
feature_importance_values = lgb.feature_importances_
feature_importances = pd.DataFrame({'feature': features, 'importance': feature_importance_values})
print(feature_importances)
feature_importances_sorted = plot_feature_importances(feature_importances)
pickle_out = open("classifier1.pkl", "wb")
pickle.dump(lgb, pickle_out)
pickle_out.close()
