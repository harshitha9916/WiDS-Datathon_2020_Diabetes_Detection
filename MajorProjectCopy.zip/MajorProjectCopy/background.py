from PIL import Image
import streamlit as st

with open("styles.css") as f:
    st.markdown('<style>{}</style>'.format(f.read()), unsafe_allow_html=True)

path = "C:/Users/HP/Downloads/download.png"
image = Image.open(path)

st.write("hello world")
st.image(image, width = 150)
st.write("bye world")