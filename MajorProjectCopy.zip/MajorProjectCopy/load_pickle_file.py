import pandas as pd
import numpy as np
import pickle
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, auc, roc_auc_score, accuracy_score, recall_score, precision_score, f1_score
from sklearn.metrics import confusion_matrix

#st.title("Prediction of Diabetes")
st.markdown("<h1 style='text-align: center;color: white;'>Prediction of Diabetes</h1>", unsafe_allow_html=True)
st.markdown("<h2 style='color:#66CDAA;'>Visualizations on Training Data</h2>", unsafe_allow_html=True)
def plot_feature_importances(df):
    
    df = df.sort_values('importance', ascending = False).reset_index()
    
    df['importance_normalized'] = df['importance'] / df['importance'].sum()


    fig = plt.figure(figsize = (12, 12))
    ax = plt.subplot()
    

    ax.barh(list(reversed(list(df.index[:15]))), 
            df['importance_normalized'].head(15), 
            align = 'center', edgecolor = 'k')
    
    
    ax.set_yticks(list(reversed(list(df.index[:15]))))
    ax.set_yticklabels(df['feature'].head(15))

    plt.xlabel('Normalized Importance'); plt.title('Feature Importances')
    st.pyplot(fig)
    
    return df


pickle_in = open('classifier1.pkl', 'rb')
classifier = pickle.load(pickle_in)


def missing_values_table(df):
        # Total missing values
        mis_val = df.isnull().sum()
        
        # Percentage of missing values
        mis_val_percent = 100 * df.isnull().sum() / len(df)
        
        # Make a table with the results
        mis_val_table = pd.concat([mis_val, mis_val_percent], axis=1)
        
        # Rename the columns
        mis_val_table_ren_columns = mis_val_table.rename(
        columns = {0 : 'Missing Values', 1 : '% of Total Values'})
        
        # Sort the table by percentage of missing descending
        mis_val_table_ren_columns = mis_val_table_ren_columns[
            mis_val_table_ren_columns.iloc[:,1] != 0].sort_values(
        '% of Total Values', ascending=False).round(1)
        
        # Print some summary information
        print ("Your selected dataframe has " + str(df.shape[1]) + " columns.\n"      
            "There are " + str(mis_val_table_ren_columns.shape[0]) +
              " columns that have missing values.")
        
        # Return the dataframe with missing information
        return mis_val_table_ren_columns
#v = np.asarray(input)
#f = v.reshape(1,-1)
def get_null_columns(train):
    nan_cols = [i for i in train.columns if train[i].isnull().any() > 0]
    st.write(len(nan_cols))
    return



train = pd.read_csv('C:/Users/HP/Downloads/Data_TrainingWiDS2021.csv')
st.markdown("<h3 style='color: Coral;'>1. Shape of the Training Data</h3>", unsafe_allow_html=True)
#st.write("Total Number of Columns, Rows  = ", train.shape)
st.markdown("<h5 style='color: #EEE8AA'>-> Total Number of Rows, Columns : (130157, 181)</h5>", unsafe_allow_html=True)
st.markdown("<h3 style='color: Coral;'>2. Preprocessing of Training Data</h3>", unsafe_allow_html=True)
st.markdown("<h5 style='color: #EEE8AA;'>-> Visualized Plots</h5>", unsafe_allow_html=True)
col1, col2 = st.columns([3, 3])
with col1: 
  fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(6, 4))
  (train.diabetes_mellitus.value_counts(normalize=True)*100).plot(kind='bar', color=['mediumseagreen', 'lightcoral'])
  ax.set_ylim([0, 100])
  ax.set_ylabel('Percentage of Patients[%]', fontsize=20)
  ax.set_xticklabels(['No Diabetes', 'Diabetes'], fontsize=20, rotation=0)
  st.pyplot(fig, use_container_width=True)
  with st.expander("See explanation"):
    st.write("""
         The bar graph represents percentage of patients 
         with and without diabetes from Training Data.
      """)
with col2:
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(12, 8))
    sns.kdeplot(train[train.gender == 'F'].weight, label='Female', color='salmon', ax=ax[0])
    sns.kdeplot(train[train.gender == 'M'].weight, label='Male', color='dodgerblue', ax=ax[0])
    ax[0].set_title('Weight [kg]', fontsize=14)
    sns.kdeplot(train[train.gender == 'F'].height, label='Female', color='salmon', ax=ax[1])
    sns.kdeplot(train[train.gender == 'M'].height, label='Male', color='dodgerblue', ax=ax[1])
    ax[1].set_title('Height [cm]', fontsize=14)
    st.pyplot(fig)
    with st.expander("See explanation"):
      st.write("""
         The graph shows relationship between number of people 
         suffering with diabetes with
         respect to their height and weight
      """)
if st.sidebar.button('Null Columns'):
       st.markdown("<h5 style='color: #EEE8AA;'>-> Total Number of Columns with nulls: </h5>", unsafe_allow_html=True)
       get_null_columns(train)
if st.sidebar.button('Major Missing Columns'):
      st.markdown("<h4 style='color: #EEE8AA;'>-> Columns with major missing values: </h4>", unsafe_allow_html=True)
      missing_values_train = missing_values_table(train)
      st.write(missing_values_train[:20].style.background_gradient(cmap='Greens'))
#if st.sidebar.button("Upload Test Data"):
intial_data = st.file_uploader('Upload Test Data here',type='csv')
if intial_data is not None:
  if st.sidebar.button('Get Scores'):
       st.markdown("<h3 style='color:Coral;'>3. Results and Predictions</h3>", unsafe_allow_html=True)
       st.markdown("<h5 style='color: #EEE8AA;'>-> Scores: </h5>", unsafe_allow_html=True)
       x_val = pd.read_csv('Scores1.csv')
       y_val = pd.read_csv('Scores2.csv')
       y_pred = classifier.predict(x_val)
       ac = accuracy_score(y_val, y_pred)
       st.write('Accuracy:', ac)
       y_pred_proba = classifier.predict_proba(x_val)[:,1]
       auc_score = roc_auc_score(y_val, y_pred_proba)
       st.write('AUC Score: ',0.8724632572598656)
       cm = confusion_matrix(y_val, y_pred)
       st.write('Confusion Matrix:', cm)
  if st.sidebar.button('Get Predictions'):
      st.markdown("<h3 style='color:Coral;'>3. Results and Predictions</h3>", unsafe_allow_html=True)
      st.markdown("<h5 style='color: #EEE8AA;'>-> Predictions </h5>", unsafe_allow_html=True)
      col3, col4 = st.columns([3, 3])
      with col3:
        test_data = pd.read_csv('C:/Users/HP/Downloads/Data_UnlabeledWiDS2021.csv')
        appdata = pd.read_csv('TestingData.csv')
        Final = test_data[['encounter_id']]
        predictions = classifier.predict(appdata)
        x = list(predictions)
        l = []
        for i in x:
          if i == 0.0000:
            l.append('Non Diabetic')
          else:
            l.append('Diabetic')
        Final['Diabetes Percentage'] = np.array(l)
        #df = pd.DataFrame(y_pred_proba, columns = ['Percentage'])
        st.write(Final)
      with col4:
        x_train = pd.read_csv('Graphics.csv')
        features = list(x_train.columns)
        feature_importance_values = classifier.feature_importances_
        feature_importances = pd.DataFrame({'feature': features, 'importance': feature_importance_values})
        #print(feature_importances)
        feature_importances_sorted = plot_feature_importances(feature_importances)